from .manager import StaticDataManager
